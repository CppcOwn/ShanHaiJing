// app.js
App({
  globalData: {
    userInfo: null,
    staticData: null,
    weatherData: null,
    forecastData: null,
    lastUpdateTime: {
      static: 0,
      weather: 0,
      forecast: 0
    }
  },
  onLaunch() {
    // 初始化数据
    this.loadStaticData();
    this.loadWeatherData();
    this.loadForecastData();
  },
  // 加载静态数据
  loadStaticData() {
    wx.request({
      url: 'https://your-cdn-domain/static/version.json',
      success: (res) => {
        if (res.data && res.data.latest) {
          wx.request({
            url: `https://your-cdn-domain/static/${res.data.latest}`,
            success: (dataRes) => {
              this.globalData.staticData = dataRes.data;
              this.globalData.lastUpdateTime.static = Date.now();
              console.log('静态数据加载成功');
            },
            fail: (err) => {
              console.error('静态数据加载失败:', err);
            }
          });
        }
      },
      fail: (err) => {
        console.error('版本信息加载失败:', err);
      }
    });
  },
  // 加载天气数据
  loadWeatherData() {
    wx.request({
      url: 'https://your-cdn-domain/weather/version.json',
      success: (res) => {
        if (res.data && res.data.latest) {
          wx.request({
            url: `https://your-cdn-domain/weather/${res.data.latest}`,
            success: (dataRes) => {
              this.globalData.weatherData = dataRes.data;
              this.globalData.lastUpdateTime.weather = Date.now();
              console.log('天气数据加载成功');
            },
            fail: (err) => {
              console.error('天气数据加载失败:', err);
            }
          });
        }
      },
      fail: (err) => {
        console.error('天气版本信息加载失败:', err);
      }
    });
  },
  // 加载自然奇观预报数据
  loadForecastData() {
    wx.request({
      url: 'https://your-cdn-domain/forecast/version.json',
      success: (res) => {
        if (res.data && res.data.latest) {
          wx.request({
            url: `https://your-cdn-domain/forecast/${res.data.latest}`,
            success: (dataRes) => {
              this.globalData.forecastData = dataRes.data;
              this.globalData.lastUpdateTime.forecast = Date.now();
              console.log('预报数据加载成功');
            },
            fail: (err) => {
              console.error('预报数据加载失败:', err);
            }
          });
        }
      },
      fail: (err) => {
        console.error('预报版本信息加载失败:', err);
      }
    });
  },
  // 检查数据是否需要更新
  checkDataUpdate() {
    const now = Date.now();
    // 静态数据 24小时更新一次
    if (now - this.globalData.lastUpdateTime.static > 24 * 60 * 60 * 1000) {
      this.loadStaticData();
    }
    // 天气数据 25分钟更新一次
    if (now - this.globalData.lastUpdateTime.weather > 25 * 60 * 1000) {
      this.loadWeatherData();
    }
    // 预报数据 4小时更新一次
    if (now - this.globalData.lastUpdateTime.forecast > 4 * 60 * 60 * 1000) {
      this.loadForecastData();
    }
  }
})